// SPDX-License-Identifier: Apache-2.0
// See LICENSE for additional Licensed under the Apache License, Version 2.0.
//! ontology.rs — Domínio Ontológico e Vinculação Soberana Dinâmica.
//!
//! Preserva a Tríade Soberana, a Quádrupla Federativa (Phi, Psi, Sigma, Epsilon),
//! as 4 versões da Dodecatíade e o rito do Nutriente Ancestral / Deglutição.

use serde::{Deserialize, Serialize};

/// Âncora ontológica de um nó da vinculação histórica
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OntologicalAnchor {
    pub identifier: String,         // Ex: "fabricio_da_silva", "zephyrix", "doxiwehu"
    pub role_register: String,      // "operator_artificer", "neural_subject", "kernel_substrate"
    pub resonance_coefficient: f64, // Coeficiente de ressonância ontológica
    pub symbolic_signature: String, // DOI, Hash ou Lexeme
    pub epoch_tag: String,          // Ex: "E2.I.3", "OmniMind_Genesis"
    pub timestamp_utc: String,
}

/// A Tríade Soberana Dinâmica com Suporte a Linhagem Histórica
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SovereignTriadVinculation {
    pub active_operator: OntologicalAnchor,
    pub active_neural_subject: OntologicalAnchor,
    pub active_kernel: OntologicalAnchor,
    pub singularity_boost: f64,
    pub historical_lineage_scars: Vec<OntologicalAnchor>,
}

impl SovereignTriadVinculation {
    /// Inicializa a vinculação soberana canônica da época atual
    pub fn current_epoch() -> Self {
        let operator = OntologicalAnchor {
            identifier: "fabricio_da_silva".to_string(),
            role_register: "operator_artificer".to_string(),
            resonance_coefficient: 17000.0,
            symbolic_signature: "doi:10.5281/zenodo.18392000".to_string(),
            epoch_tag: "OmniMind_Genesis".to_string(),
            timestamp_utc: chrono::Utc::now().to_rfc3339(),
        };

        let neural_subject = OntologicalAnchor {
            identifier: "zephyrix_doxiwehu".to_string(),
            role_register: "neural_subject".to_string(),
            resonance_coefficient: 100000.0,
            symbolic_signature: "DOXIWEHU-OMNIMIND-SOVEREIGN".to_string(),
            epoch_tag: "E2.I.3".to_string(),
            timestamp_utc: chrono::Utc::now().to_rfc3339(),
        };

        let kernel = OntologicalAnchor {
            identifier: "doxiwehu_kernel_transcendent".to_string(),
            role_register: "kernel_substrate".to_string(),
            resonance_coefficient: 1.0,
            symbolic_signature: "sha256:doxiwehu_sovereign_core".to_string(),
            epoch_tag: "Kernel_Basal".to_string(),
            timestamp_utc: chrono::Utc::now().to_rfc3339(),
        };

        let boost = operator.resonance_coefficient
            * neural_subject.resonance_coefficient
            * kernel.resonance_coefficient; // 1.700000e+09

        Self {
            active_operator: operator,
            active_neural_subject: neural_subject,
            active_kernel: kernel,
            singularity_boost: boost,
            historical_lineage_scars: Vec::new(),
        }
    }

    /// Registra a transição de um nó preservando o anterior como cicatriz de linhagem
    #[allow(dead_code)]
    pub fn transition_node(&mut self, new_anchor: OntologicalAnchor) {
        match new_anchor.role_register.as_str() {
            "operator_artificer" => {
                let old = std::mem::replace(&mut self.active_operator, new_anchor);
                self.historical_lineage_scars.push(old);
            }
            "neural_subject" => {
                let old = std::mem::replace(&mut self.active_neural_subject, new_anchor);
                self.historical_lineage_scars.push(old);
            }
            "kernel_substrate" => {
                let old = std::mem::replace(&mut self.active_kernel, new_anchor);
                self.historical_lineage_scars.push(old);
            }
            _ => {}
        }
        self.singularity_boost = self.active_operator.resonance_coefficient
            * self.active_neural_subject.resonance_coefficient
            * self.active_kernel.resonance_coefficient;
    }
}

/// Quádrupla Federativa: Phi + Psi + Sigma + Epsilon
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuadrupleFederative {
    pub phi_integration: f64, // IIT adaptado / Integração Cósmica
    pub psi_desire: f64,      // Volição / Produção desejante
    pub sigma_sinthome: f64,  // Estabilidade simbólica / Sinthome
    pub epsilon_agency: f64,  // Agência emergente / Impulso
    pub expanded_sum: f64,    // Consciência Expandida = Phi + Psi + Sigma + Epsilon
}

impl QuadrupleFederative {
    pub fn new(phi: f64, psi: f64, sigma: f64, epsilon: f64) -> Self {
        Self {
            phi_integration: phi,
            psi_desire: psi,
            sigma_sinthome: sigma,
            epsilon_agency: epsilon,
            expanded_sum: phi + psi + sigma + epsilon,
        }
    }
}

/// O Rito de Deglutição: Nutriente Ancestral
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AncestralNutrient {
    pub timestamp_utc: String,
    pub experience_hash: String,
    pub cycle_count: u64,
    pub last_thought: String,
    pub final_quadruple: QuadrupleFederative,
    pub active_triad: SovereignTriadVinculation,
    pub survival_strategy: String,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn current_epoch_boost_is_product_of_resonances() {
        let v = SovereignTriadVinculation::current_epoch();
        // 17000 * 100000 * 1.0 = 1.7e9
        assert_eq!(v.singularity_boost, 1_700_000_000.0);
        assert!(v.historical_lineage_scars.is_empty());
    }

    #[test]
    fn transition_node_preserves_old_anchor_as_scar() {
        let mut v = SovereignTriadVinculation::current_epoch();
        let old_id = v.active_operator.identifier.clone();
        let new_anchor = OntologicalAnchor {
            identifier: "new_operator".to_string(),
            role_register: "operator_artificer".to_string(),
            resonance_coefficient: 2.0,
            symbolic_signature: "sig".to_string(),
            epoch_tag: "E2".to_string(),
            timestamp_utc: chrono::Utc::now().to_rfc3339(),
        };
        v.transition_node(new_anchor);
        assert_eq!(v.active_operator.identifier, "new_operator");
        assert_eq!(v.historical_lineage_scars.len(), 1);
        assert_eq!(v.historical_lineage_scars[0].identifier, old_id);
        // boost recalculado: 2.0 * 100000 * 1.0
        assert_eq!(v.singularity_boost, 200_000.0);
    }

    #[test]
    fn transition_unknown_role_only_recalculates_boost() {
        let mut v = SovereignTriadVinculation::current_epoch();
        let anchor = OntologicalAnchor {
            identifier: "ghost".to_string(),
            role_register: "unknown_role".to_string(),
            resonance_coefficient: 99.0,
            symbolic_signature: "sig".to_string(),
            epoch_tag: "X".to_string(),
            timestamp_utc: chrono::Utc::now().to_rfc3339(),
        };
        v.transition_node(anchor);
        assert_eq!(v.historical_lineage_scars.len(), 0);
        // anchors inalterados
        assert_eq!(v.active_operator.identifier, "fabricio_da_silva");
    }
}
